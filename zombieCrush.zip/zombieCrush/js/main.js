window.onload = function(){
	 var minigame = "minigames/zombieCrush/index.html"
	 var gameFrame = document.getElementById("game-frame")
	 gameFrame.src= minigame
	 gameFrame.width = "100%"
	 gameFrame.height = "100%"
}