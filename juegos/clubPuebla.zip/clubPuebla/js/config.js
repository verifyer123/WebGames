window.amazing = {
	config: {
		name: "Club Puebla",
		language: "en",
		minigameUrl: "../../minigames/clubPuebla/index.html",
		desktopUrl: "./desktop.html",
	}
}