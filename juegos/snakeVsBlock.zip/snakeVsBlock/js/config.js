window.amazing = {
	config: {
		name: "Snake vs Block",
		language: "en",
		minigameUrl: "../../minigames/snakeVsBlock/index.html",
		desktopUrl: "./desktop.html",
	}
}