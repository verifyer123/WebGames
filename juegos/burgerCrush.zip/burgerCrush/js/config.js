window.amazing = {
	config: {
		name: "Burger Crush",
		language: "en",
		minigameUrl: "../../minigames/burgerCrush/index.html",
		desktopUrl: "./desktop.html",
	}
}