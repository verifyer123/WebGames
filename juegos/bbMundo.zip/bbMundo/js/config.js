window.amazing = {
	config: {
		name: "BB Mundo",
		language: "en",
		minigameUrl: "../../minigames/bbMundo/index.html",
		desktopUrl: "./desktop.html",
	}
}