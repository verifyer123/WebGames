window.amazing = {
	config: {
		name: "Neon Edge",
		minigameUrl: "../../minigames/nutribaby/index.html",
		desktopUrl: "./desktop.html",	
	}
}