window.amazing = {
	config: {
		name: "Neon Edge",
		minigameUrl: "../../minigames/cirquitNetshoes/index.html",
		desktopUrl: "./desktop.html",	
	}
}