window.amazing = {
	config: {
		name: "Neon Edge",
		minigameUrl: "../../minigames/cirquit/index.html",
		desktopUrl: "./desktop.html",	
	}
}