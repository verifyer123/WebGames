window.amazing = {
	config: {
		name: "Snoopy En Busca Del Sabor",
		language: "en",
		minigameUrl: "../../minigames/snoopyEnBuscaDelSabor/index.html",
		desktopUrl: "./desktop.html",
	}
}