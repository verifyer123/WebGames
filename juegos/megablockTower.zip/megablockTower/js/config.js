window.amazing = {
	config: {
		name: "Megablocks",
		language: "en",
		minigameUrl: "../../minigames/megablockTower/index.html",
		desktopUrl: "./desktop.html",
	}
}